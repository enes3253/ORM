from django.urls import path     
from . import views

urlpatterns = [
    path(r'^shows$', views.index),
    path(r"^add_show$", views.add_show),
    path(r"^submit_show$", views.submit_show),
    path(r"^display_show/(?P<id>\d)$", views.display_show),
    path(r"^edit_show/(?P<id>\d)$", views.edit_show),
    path(r"^submit_edit/(?P<id>\d)$", views.submit_edit),
    path(r"^delete_show/(?P<id>\d)$", views.delete_show),
]