from django.apps import AppConfig


class TvShowAppConfig(AppConfig):
    name = 'tv_show_app'
